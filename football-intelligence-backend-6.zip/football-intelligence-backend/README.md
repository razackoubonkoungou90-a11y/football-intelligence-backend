# Football Intelligence AI — Backend (démarrage)

Backend FastAPI qui combine deux sources réelles :
- **API-Football** (api-sports.io) → les matchs réels (équipes, compétitions, horaires)
- **The Odds API** (the-odds-api.com) → des cotes réelles agrégées de bookmakers mainstream

## Installation

```bash
python -m venv venv
source venv/bin/activate   # Windows : venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

Puis va chercher tes clés gratuites :
- https://www.api-football.com/ (plan gratuit ~100 requêtes/jour)
- https://the-odds-api.com/ (plan gratuit 500 crédits/mois)

Colle-les dans `.env`.

## Lancer le serveur

```bash
uvicorn app.main:app --reload
```

Puis ouvre http://127.0.0.1:8000/docs pour tester les endpoints directement (interface Swagger auto-générée).

## Endpoints

- `GET /fixtures?date=2026-09-26` → liste des vrais matchs du jour
- `POST /coupon` → génère une sélection dont la cote totale approche l'intervalle demandé
  ```json
  {"date": "2026-09-26", "sports": ["football"], "odd_min": 3, "odd_max": 15, "max_matches": 6}
  ```
- `POST /predict/match` → probabilités Poisson (1N2, over/under 2.5, BTTS) pour un match, à partir des vraies stats de saison des deux équipes
  ```json
  {"home_team_id": 33, "away_team_id": 34, "league_id": 39, "season": 2026}
  ```
  (les `team_id` / `league_id` s'obtiennent via les endpoints `/teams` et `/leagues` d'API-Football)
- `POST /predict/coupon` → **probabilité réelle simulée (Monte Carlo)** que tout le coupon passe en même temps, à comparer à la cote totale d'un bookmaker
  ```json
  {
    "picks": [
      {"home_team_id": 33, "away_team_id": 34, "league_id": 39, "season": 2026, "market": "home_win"},
      {"home_team_id": 40, "away_team_id": 42, "league_id": 39, "season": 2026, "market": "over_2_5"}
    ],
    "simulations": 20000
  }
  ```
  La réponse donne `coupon_probability` (ex: 0.031 = 3.1% de chances réelles) et `fair_odd_if_probability_exact` — compare ce nombre à la cote annoncée par le bookmaker : si la cote du bookmaker est nettement plus basse que la cote "juste" calculée ici, c'est la marge du bookmaker (normal, c'est comme ça qu'il gagne de l'argent sur la durée).

## Limites importantes à garder en tête

1. **Megapari, 1xBet et 1win n'ont pas d'API publique.** Les cotes obtenues ici viennent d'autres bookmakers (Bet365, Pinnacle, etc. selon la région choisie) — ce sont des cotes de référence, pas une copie garantie.
2. **Aucun "code de coupon" généré ici n'est valable sur une vraie plateforme.** Il n'existe pas de moyen légitime de créer un coupon jouable directement sur Megapari/1xBet/1win depuis l'extérieur — il faudrait le composer manuellement sur leur site avec ces sélections comme base.
3. Plus tu demandes de matchs / une cote totale élevée, plus la probabilité réelle que tout se réalise baisse mathématiquement — ce backend ne change rien à ça, il fournit juste de meilleures données de départ.
4. Prochaines étapes possibles : base de données (historique + backtesting), cache Redis pour ne pas dépasser les quotas gratuits des API, mise en correspondance des noms d'équipes plus robuste (actuellement une simple égalité de chaînes), interface frontend pour visualiser tout ça.

## Déployer le backend (pour qu'il soit accessible depuis internet)

### Option A — Render (recommandé, gratuit pour démarrer)
1. Crée un compte sur https://render.com et connecte ton dépôt GitHub (pousse d'abord ce dossier sur GitHub).
2. "New +" → "Blueprint" → sélectionne le dépôt. Render détecte `render.yaml` automatiquement.
3. Renseigne `API_FOOTBALL_KEY` et `ODDS_API_KEY` dans les variables d'environnement (Render te les demande car elles sont marquées `sync: false`).
4. Déploie. Tu obtiens une URL du type `https://football-intelligence-backend.onrender.com`.
5. Teste avec `https://ton-url.onrender.com/docs`.

*Note : sur le plan gratuit, le service "s'endort" après 15 min d'inactivité et met ~30s à se réveiller au prochain appel — normal, pas un bug.*

### Option B — Railway
1. Compte sur https://railway.app, "New Project" → "Deploy from GitHub repo".
2. Railway lit le `Procfile` automatiquement.
3. Ajoute les mêmes variables d'environnement dans l'onglet "Variables".

### Option C — En local pour tester tout de suite (sans déploiement)
Suis juste la section "Installation" plus haut — tu peux tout tester sur `http://127.0.0.1:8000/docs` sans rien déployer, tant que tu es la seule personne à devoir y accéder.
